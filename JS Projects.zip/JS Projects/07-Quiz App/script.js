const quizData = [
  {
    question: "How old is Dua?",
    a: "10",
    b: "17",
    c: "3",
    d: "9",
    correct: "c",
  },
  {
    question: "What is the most used programming language in 2023?",
    a: "Java",
    b: "C",
    c: "Python",
    d: "JavaScript",
    correct: "a",
  },
  {
    question: "Who is the President of US?",
    a: "Florin Pop",
    b: "Donald Trump",
    c: "Ivan Saldano",
    d: "Joe Biden",
    correct: "d",
  },
  {
    question: "What does HTML Stand's for?",
    a: "HyperText",
    b: "Hyper Text Markup Language",
    c: " Cascading language",
    d: "Heli Termi MOtor",
    correct: "b",
  },
  {
    question: "What year was JavaScript Launched?",
    a: "2020",
    b: "1995",
    c: "1992",
    d: "1990",
    correct: "b",
  },
];

const questionE1 = document.getElementById("question");

const a_text = document.getElementById("a_text");
const b_text = document.getElementById("b_text");
const c_text = document.getElementById("c_text");
const d_text = document.getElementById("d_text");
const submitBtn = document.getElementById("submit");

let currentQuiz = 0;
let score = 0;

loadQuiz();

function loadQuiz() {
  const currentQuizData = quizData[currentQuiz];

  questionE1.innerText = currentQuizData.question;
  a_text.innerText = currentQuizData.a;
  b_text.innerText = currentQuizData.b;
  c_text.innerText = currentQuizData.c;
  d_text.innerText = currentQuizData.d;
}

function getSelected(){

   const answerELs = document.querySelectorAll('.answer');

   answers.forEach((answerEL)=>{
    if(answerEL.checked) {
       return answerEL.id;
    }
    return undefined


   });
}


submitBtn.addEventListener("click", () => {
    currentQuiz++;
    
    const answer = getSelected();

    if(answer) {

        if (currentQuiz < quizData.length) {
            loadQuiz();
          } else {
            // ToDo: Show results
            alert(" You finished get yourself a lemondade");
          })
    }


});
